package card;

public interface ICardFactory {
	Card createCard(String cardName);
}
