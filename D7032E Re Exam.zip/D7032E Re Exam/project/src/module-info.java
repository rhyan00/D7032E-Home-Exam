/**
 * 
 */
module take_home_exam_re {
	requires org.junit.jupiter.api;
}